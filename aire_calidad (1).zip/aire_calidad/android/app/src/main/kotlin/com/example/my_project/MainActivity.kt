package com.mycompany.airecalidad

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
